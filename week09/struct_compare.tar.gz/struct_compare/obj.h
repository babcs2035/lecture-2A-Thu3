#pragma once

typedef struct obj{
    double a;
    char b;
    double c;
} Obj;

// 入力されたObject構造体にちょっと細工したものを返す関数
Obj trick(Obj x);
 
